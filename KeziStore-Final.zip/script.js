document.querySelectorAll('.card-produk button').forEach(btn => {
  btn.addEventListener('click', () => alert('Produk ditambahkan ke keranjang!'));
});